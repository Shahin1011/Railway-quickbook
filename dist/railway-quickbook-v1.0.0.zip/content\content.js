/**
 * Railway QuickBook – Content Script & Angular SPA Autofill Engine (Phase 4 & 5)
 * Target: https://eticket.railway.gov.bd/*
 * Full bilingual support (English & Bangla)
 */

(() => {
  // Prevent multiple injections on the same tab
  if (window.__RQB_INITIALIZED__) return;
  window.__RQB_INITIALIZED__ = true;

  const fallbackDefault = (window.RAILWAY_DATA && window.RAILWAY_DATA.defaultConfig) || {
    lang: "en",
    enabled: true,
    fromStation: "Dhaka",
    toStation: "Chattogram",
    journeyDate: "",
    seatClass: "S_CHAIR",
    adultCount: 1,
    childCount: 0,
    preferredTrains: ["SUBORNO EXPRESS", "SONAR BANGLA EXPRESS"],
    coPassengers: [],
    options: {
      autoSubmitSearch: true,
      autoHighlightTrains: true,
      autoScrollToPreferred: true,
      autoExpandPreferredClass: false,
      dimNonPreferredTrains: false,
      showFloatingWidget: true
    }
  };

  let config = structuredClone(fallbackDefault);
  let hasScrolledCurrentSearch = false;
  let lastUrl = location.href;

  // =========================================================================
  // 1. Helpers: i18n, Date Formatting & Angular Native Value Setter
  // =========================================================================

  function getI18n(key, interpolations = {}) {
    const lang = config.lang || "en";
    const dict = (window.RQB_I18N && window.RQB_I18N[lang]) || (window.RQB_I18N && window.RQB_I18N.en) || {};
    let text = dict[key] || "";
    Object.keys(interpolations).forEach((k) => {
      text = text.replace(new RegExp(`\\{${k}\\}`, "g"), interpolations[k]);
    });
    return text;
  }

  function formatToRailwayDate(isoDate) {
    if (!isoDate) return "";
    // Convert YYYY-MM-DD -> DD-MMM-YYYY (e.g. 20-Nov-2026)
    const parts = isoDate.split("-");
    if (parts.length !== 3) return isoDate;
    const months = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const mIdx = parseInt(parts[1], 10) - 1;
    return `${parts[2]}-${months[mIdx] || parts[1]}-${parts[0]}`;
  }

  /**
   * Sets value on an HTMLInputElement or HTMLSelectElement in a way that
   * Angular FormControl / NgModel and jQuery listeners detect immediately.
   */
  function setNativeValue(element, value) {
    if (!element) return false;
    const tag = element.tagName.toLowerCase();
    const proto =
      tag === "select"
        ? window.HTMLSelectElement.prototype
        : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "value");

    element.focus();
    if (descriptor && descriptor.set) {
      descriptor.set.call(element, value);
    } else {
      element.value = value;
    }

    element.dispatchEvent(new Event("focus", { bubbles: true }));
    element.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "a" }));
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "a" }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Find first matching visible element from a list of CSS selectors
  function queryFirst(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  // =========================================================================
  // 2. Search Form Autofill (From, To, Date, Seat Class, Search Submit)
  // =========================================================================

  async function fillStationField(inputEl, stationName) {
    if (!inputEl || !stationName) return false;
    setNativeValue(inputEl, stationName);
    await sleep(140);

    // Check if an autocomplete / typeahead list popped up (jQuery UI, Angular, or custom ul)
    const candidateItems = document.querySelectorAll(
      ".ui-autocomplete li, ul[id^='ui-id-'] li, .autocomplete-items div, .ng-dropdown-panel .ng-option, mat-option, .station-list li, ul.dropdown-menu li"
    );

    const targetLower = stationName.toLowerCase().replace(/_/g, " ");
    let clickedItem = false;

    for (const item of candidateItems) {
      if (item.offsetParent === null) continue; // skip hidden
      const text = (item.textContent || "").trim().toLowerCase().replace(/_/g, " ");
      if (text === targetLower || text.startsWith(targetLower) || text.includes(targetLower)) {
        item.click();
        clickedItem = true;
        break;
      }
    }

    if (!clickedItem) {
      inputEl.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", keyCode: 13, bubbles: true }));
      inputEl.dispatchEvent(new Event("blur", { bubbles: true }));
    }
    return true;
  }

  async function fillDateField(dateEl, isoDate) {
    if (!dateEl || !isoDate) return false;
    const formatted = formatToRailwayDate(isoDate); // e.g., 20-Nov-2026
    const [, , dayNum] = isoDate.split("-");
    const dayInt = parseInt(dayNum, 10);

    const hadReadonly = dateEl.hasAttribute("readonly");
    if (hadReadonly) dateEl.removeAttribute("readonly");

    dateEl.click();
    setNativeValue(dateEl, formatted);
    await sleep(120);

    const dayCells = document.querySelectorAll(
      ".ui-datepicker-calendar td:not(.ui-datepicker-other-month):not(.ui-state-disabled) a, .mat-calendar-body-cell:not(.mat-calendar-body-disabled), .bs-datepicker-body td span:not(.disabled)"
    );

    for (const cell of dayCells) {
      if (cell.offsetParent === null) continue;
      const cellText = (cell.textContent || "").trim();
      if (parseInt(cellText, 10) === dayInt) {
        cell.click();
        break;
      }
    }

    if (!dateEl.value) {
      setNativeValue(dateEl, formatted);
    }
    dateEl.dispatchEvent(new Event("change", { bubbles: true }));
    dateEl.dispatchEvent(new Event("blur", { bubbles: true }));

    if (hadReadonly) dateEl.setAttribute("readonly", "true");
    return true;
  }

  async function fillSeatClassField(selectEl, seatClassCode) {
    if (!selectEl || !seatClassCode) return false;

    if (selectEl.tagName.toLowerCase() === "select") {
      const options = Array.from(selectEl.options || []);
      const match = options.find(
        (opt) =>
          opt.value.toUpperCase() === seatClassCode.toUpperCase() ||
          opt.textContent.toUpperCase().includes(seatClassCode.toUpperCase())
      );
      setNativeValue(selectEl, match ? match.value : seatClassCode);
      selectEl.dispatchEvent(new Event("blur", { bubbles: true }));
      return true;
    } else {
      selectEl.click();
      await sleep(100);
      setNativeValue(selectEl, seatClassCode);
      return true;
    }
  }

  async function autofillSearchForm(forceSubmit = null) {
    if (config.enabled === false) {
      updateWidgetStatus(config.lang === "bn" ? "⏸️ QuickBook বন্ধ (OFF) আছে। আগে ON করুন।" : "⏸️ QuickBook is Paused (OFF). Please turn ON first.");
      return;
    }
    updateWidgetStatus(getI18n("widgetAutofilling"));

    const fromInput = queryFirst([
      "#dest_from",
      "input[formcontrolname='dest_from']",
      "input[formcontrolname='from_station']",
      "input[name='dest_from']",
      "input[placeholder*='From Station' i]",
      "input[placeholder*='From' i]"
    ]);

    const toInput = queryFirst([
      "#dest_to",
      "input[formcontrolname='dest_to']",
      "input[formcontrolname='to_station']",
      "input[name='dest_to']",
      "input[placeholder*='To Station' i]",
      "input[placeholder*='To' i]"
    ]);

    const dateInput = queryFirst([
      "#doj",
      "input[formcontrolname='doj']",
      "input[name='doj']",
      "input[placeholder*='Date' i]",
      "input[placeholder*='Pick a date' i]"
    ]);

    const classSelect = queryFirst([
      "#choose_class",
      "select[formcontrolname='choose_class']",
      "select[name='choose_class']",
      "select#choose_class",
      "form select"
    ]);

    if (!fromInput && !toInput && !dateInput) {
      const paxFilled = autofillPassengerDetails();
      if (paxFilled > 0) {
        updateWidgetStatus(getI18n("widgetPaxFilled", { count: paxFilled }));
        return;
      }
      highlightPreferredTrains();
      updateWidgetStatus(getI18n("widgetFormNotFound"));
      return;
    }

    if (fromInput) await fillStationField(fromInput, config.fromStation);
    await sleep(100);
    if (toInput) await fillStationField(toInput, config.toStation);
    await sleep(100);
    if (dateInput) await fillDateField(dateInput, config.journeyDate);
    await sleep(100);
    if (classSelect) await fillSeatClassField(classSelect, config.seatClass);

    updateWidgetStatus(getI18n("widgetAutofillDone"));

    const shouldSubmit =
      forceSubmit !== null ? forceSubmit : !!(config.options && config.options.autoSubmitSearch);

    if (shouldSubmit) {
      await sleep(180);
      const searchBtn =
        queryFirst([
          "button.railway-ticket-search-submit-btn",
          "form button[type='submit']",
          ".search-form button[type='submit']"
        ]) ||
        Array.from(document.querySelectorAll("button")).find((b) =>
          /search\s*trains/i.test(b.textContent || "")
        );

      if (searchBtn && !searchBtn.disabled) {
        hasScrolledCurrentSearch = false;
        searchBtn.click();
        updateWidgetStatus(getI18n("widgetSearchClicked"));
      }
    }
  }

  // =========================================================================
  // 3. Preferred Train & Seat Class Highlighter on Search Results
  // =========================================================================

  function normalizeTrainString(str) {
    return (str || "")
      .toUpperCase()
      .replace(/['’`._\-\s]/g, "");
  }

  function getCardTrainTitle(card) {
    if (!card) return "";
    const heading = card.querySelector(
      "h1, h2, h3, h4, h5, .train-name, .trip-title, .trip-head, [class*='train-name'], [class*='trip-name']"
    );
    if (heading) {
      return (heading.textContent || "").trim();
    }
    // Fallback: examine the first non-empty line of text in the card
    const lines = (card.innerText || card.textContent || "")
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean);
    return lines.length > 0 ? lines[0] : "";
  }

  function trainMatches(titleText, cardText, pref) {
    if (!pref) return false;
    const normPref = normalizeTrainString(pref);
    if (!normPref) return false;

    // 1. Primary check: Train Title/Heading (prevents route/destination station false positives)
    if (titleText) {
      const normTitle = normalizeTrainString(titleText);
      if (normTitle.includes(normPref) || normPref.includes(normTitle)) {
        return true;
      }

      // Check numbers in pref (e.g. "814", "813/814") against title
      const prefNumbers = pref.match(/\b\d{3,4}\b/g);
      if (prefNumbers) {
        for (const num of prefNumbers) {
          if (new RegExp(`\\b${num}\\b`).test(titleText)) return true;
        }
      }

      // Check numbers from popularTrains DB in title
      if (window.RAILWAY_DATA && window.RAILWAY_DATA.popularTrains) {
        const matchInDb = window.RAILWAY_DATA.popularTrains.find(
          (t) =>
            normalizeTrainString(t.name) === normPref ||
            normPref.includes(normalizeTrainString(t.name))
        );
        if (matchInDb && matchInDb.numbers) {
          for (const num of matchInDb.numbers) {
            if (new RegExp(`\\b${num}\\b`).test(titleText)) return true;
          }
        }
      }
    }

    // 2. Secondary check: Card text (for pure number search or un-headed layouts)
    if (cardText) {
      const prefNumbers = pref.match(/\b\d{3,4}\b/g);
      if (prefNumbers) {
        for (const num of prefNumbers) {
          if (new RegExp(`\\b${num}\\b`).test(cardText)) return true;
        }
      }

      // If pref has a matching popular train in DB with specific numbers
      if (window.RAILWAY_DATA && window.RAILWAY_DATA.popularTrains) {
        const matchInDb = window.RAILWAY_DATA.popularTrains.find(
          (t) =>
            normalizeTrainString(t.name) === normPref ||
            normPref.includes(normalizeTrainString(t.name))
        );
        if (matchInDb && matchInDb.numbers) {
          for (const num of matchInDb.numbers) {
            if (new RegExp(`\\b${num}\\b`).test(cardText)) return true;
          }
        }
      }
    }

    return false;
  }

  let isApplyingHighlight = false;

  function highlightPreferredTrains() {
    if (isApplyingHighlight) return 0;
    isApplyingHighlight = true;
    try {
      return _executeHighlight();
    } finally {
      setTimeout(() => {
        isApplyingHighlight = false;
      }, 200);
    }
  }

  function _executeHighlight() {
    // If master toggle is OFF or highlight is disabled, remove any existing highlights and return
    if (config.enabled === false || (config.options && config.options.autoHighlightTrains === false)) {
      document.querySelectorAll(".rqb-preferred-train-card, .rqb-dimmed-train-card").forEach((el) => {
        el.classList.remove("rqb-preferred-train-card", "rqb-dimmed-train-card");
      });
      document.querySelectorAll(".rqb-preferred-badge").forEach((el) => el.remove());
      return 0;
    }

    const preferredList = (config.preferredTrains || [])
      .map((t) => t.trim().toUpperCase())
      .filter(Boolean);

    // If no preferred trains configured, clean up any existing badges and highlights
    if (preferredList.length === 0) {
      document.querySelectorAll(".rqb-preferred-train-card, .rqb-dimmed-train-card").forEach((el) => {
        el.classList.remove("rqb-preferred-train-card", "rqb-dimmed-train-card");
      });
      document.querySelectorAll(".rqb-preferred-badge").forEach((el) => el.remove());
      document.querySelectorAll(".rqb-preferred-seat-class").forEach((el) => el.classList.remove("rqb-preferred-seat-class"));
      return 0;
    }

    const allCandidates = Array.from(
      document.querySelectorAll(
        "app-single-trip, .single-trip-wrapper, .trip-card, .train-card, .single-trip, div[class*='single-trip']"
      )
    );

    // If app-single-trip tags are present, prioritize them exclusively to avoid nested duplicates
    const appSingleTrips = allCandidates.filter((el) => el.tagName.toLowerCase() === "app-single-trip");
    let cards = appSingleTrips.length > 0 ? appSingleTrips : allCandidates;

    // Filter out any element that is contained within another candidate card
    cards = cards.filter((el) => !cards.some((parent) => parent !== el && parent.contains(el)));

    if (cards.length === 0) {
      const headings = Array.from(document.querySelectorAll("h2, h3, h4, h5, .train-name")).filter(
        (h) => /\(\d{3,4}\)/.test(h.textContent || "")
      );
      cards = headings
        .map((h) => h.closest(".card, .row, section, div.mb-3, div.p-3") || h.parentElement)
        .filter((c, idx, self) => c && self.indexOf(c) === idx);
    }

    if (cards.length === 0) return 0;

    let matchedCards = [];

    // 1. Identify which cards match the user's preferred list and assign priority
    cards.forEach((card) => {
      const titleText = getCardTrainTitle(card);
      const cardText = (card.textContent || "").toUpperCase();
      let matchedPriority = -1;
      let matchedName = "";

      for (let i = 0; i < preferredList.length; i++) {
        const pref = preferredList[i];
        if (trainMatches(titleText, cardText, pref)) {
          matchedPriority = i + 1;
          matchedName = pref;
          break;
        }
      }

      if (matchedPriority > 0) {
        matchedCards.push({ card, priority: matchedPriority, name: matchedName });
      }
    });

    // 2. Sort by priority so #1 is first
    matchedCards.sort((a, b) => a.priority - b.priority);

    // 3. User requirement: If multiple preferred trains exist, only the top #1 match is selected with border
    const topMatch = matchedCards.length > 0 ? matchedCards[0] : null;

    cards.forEach((card) => {
      const isSelectedNum1 = topMatch && topMatch.card === card;

      if (isSelectedNum1) {
        if (!card.classList.contains("rqb-preferred-train-card")) {
          card.classList.add("rqb-preferred-train-card");
        }
        if (card.classList.contains("rqb-dimmed-train-card")) {
          card.classList.remove("rqb-dimmed-train-card");
        }

        const badgePrefix = getI18n("widgetTrainBadge");
        const classLabel = config.lang === "bn" ? "লক্ষ্য ক্লাস:" : "Target Class:";
        const badgeHtml = `${badgePrefix}${topMatch.priority} (${topMatch.name}) • ${classLabel} ${config.seatClass}`;

        let badge = card.querySelector(".rqb-preferred-badge");
        if (!badge) {
          badge = document.createElement("div");
          badge.className = "rqb-preferred-badge";
          badge.innerHTML = badgeHtml;
          card.prepend(badge);
        } else if (badge.innerHTML !== badgeHtml) {
          badge.innerHTML = badgeHtml;
        }

        // Clean up any extra duplicate badges if any
        const extraBadges = Array.from(card.querySelectorAll(".rqb-preferred-badge")).slice(1);
        if (extraBadges.length > 0) {
          extraBadges.forEach((b) => b.remove());
        }

        highlightSeatClassInCard(card, config.seatClass);
      } else {
        // Any other train must NOT have the border/badge
        if (card.classList.contains("rqb-preferred-train-card")) {
          card.classList.remove("rqb-preferred-train-card");
        }
        const strayBadges = card.querySelectorAll(".rqb-preferred-badge");
        if (strayBadges.length > 0) {
          strayBadges.forEach((b) => b.remove());
        }
        card.querySelectorAll(".rqb-preferred-seat-class").forEach((sc) => sc.classList.remove("rqb-preferred-seat-class"));

        if (config.options && config.options.dimNonPreferredTrains) {
          if (!card.classList.contains("rqb-dimmed-train-card")) {
            card.classList.add("rqb-dimmed-train-card");
          }
        } else {
          if (card.classList.contains("rqb-dimmed-train-card")) {
            card.classList.remove("rqb-dimmed-train-card");
          }
        }
      }
    });

    if (topMatch) {
      if (!hasScrolledCurrentSearch && (!config.options || config.options.autoScrollToPreferred !== false)) {
        hasScrolledCurrentSearch = true;
        topMatch.card.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      updateWidgetStatus(getI18n("widgetTrainsFound", { count: 1 }));
      return 1;
    }

    return 0;
  }

  function highlightSeatClassInCard(trainCard, targetClassCode) {
    if (!trainCard || !targetClassCode) return;
    const cleanTarget = targetClassCode.trim().toUpperCase().replace(/[\s-]/g, "_");

    const classElements = trainCard.querySelectorAll(
      ".single-seat-class, .seat-class-card, .class-box, div[class*='seat-class'], li"
    );

    classElements.forEach((box) => {
      const titleEl = box.querySelector("h4, h5, .class-name, .seat-class-title, b, strong") || box;
      const rawText = (titleEl.textContent || "").toUpperCase().replace(/[\s-]/g, "_");

      const isExactMatch =
        rawText.includes(cleanTarget) &&
        (cleanTarget === "S_CHAIR" ? !rawText.includes("AC_S") : true) &&
        (cleanTarget === "AC_S" ? !rawText.includes("S_CHAIR") : true);

      if (isExactMatch) {
        box.classList.add("rqb-preferred-seat-class");
      } else {
        box.classList.remove("rqb-preferred-seat-class");
      }
    });
  }

  // =========================================================================
  // 4. Co-Passenger Details Autofill (Checkout / Passenger Info Page)
  // =========================================================================

  function autofillPassengerDetails() {
    const coPassengers = (config.coPassengers || []).filter((p) => p && p.name && p.name.trim());
    if (coPassengers.length === 0) return 0;

    const nameInputs = Array.from(
      document.querySelectorAll(
        "input[formcontrolname*='passenger' i], input[name*='passenger' i], input[id*='passenger' i], input[placeholder*='Passenger Name' i], input[placeholder*='Full Name' i]"
      )
    ).filter((el) => el.type === "text" && !el.readOnly && !el.disabled);

    if (nameInputs.length === 0) return 0;

    let filledCount = 0;
    const targetInputs = nameInputs.filter((inp, idx) => idx > 0 || !inp.value.trim());

    for (let i = 0; i < Math.min(coPassengers.length, targetInputs.length); i++) {
      const pax = coPassengers[i];
      const inputEl = targetInputs[i];
      if (pax.name && inputEl) {
        setNativeValue(inputEl, pax.name.trim());
        inputEl.dispatchEvent(new Event("blur", { bubbles: true }));
        filledCount++;
      }
    }

    return filledCount;
  }

  // =========================================================================
  // 5. On-Page Floating QuickBook Assistant Widget
  // =========================================================================

  function createOrUpdateFloatingWidget() {
    let widget = document.getElementById("rqb-floating-widget");

    if (config.options && config.options.showFloatingWidget === false) {
      if (widget) widget.style.display = "none";
      return;
    }

    const isBn = config.lang === "bn";
    const headerTitle = isBn ? "ক্লিক করে ছোট/বড় করুন" : "Click to expand/minimize";
    const switchTitle = isBn ? "QuickBook অন/অফ করুন" : "QuickBook On/Off";
    const minimizeTitle = isBn ? "মিনিমাইজ" : "Minimize";

    if (!widget) {
      widget = document.createElement("div");
      widget.id = "rqb-floating-widget";
      widget.innerHTML = `
        <div class="rqb-widget-header" id="rqbWidgetHeader" title="${headerTitle}">
          <div class="rqb-header-left">
            <span>🚆 QuickBook</span>
            <span class="rqb-live-clock" id="rqbLiveClock">--:--:--</span>
          </div>
          <div class="rqb-header-actions" onclick="event.stopPropagation();">
            <label class="rqb-widget-switch" title="${switchTitle}">
              <input type="checkbox" id="rqbWidgetToggle" ${config.enabled !== false ? "checked" : ""} />
              <span class="rqb-slider"></span>
            </label>
            <button type="button" class="rqb-toggle-btn" id="rqbMinimizeBtn" title="${minimizeTitle}">_</button>
          </div>
        </div>
        <div class="rqb-widget-body">
          <div class="rqb-route-summary">
            <div class="rqb-route-line">
              <span id="rqbRouteText">Dhaka ➔ Chattogram</span>
            </div>
            <div class="rqb-meta-line">
              <span id="rqbDateText">--</span> •
              <span id="rqbClassText">S_CHAIR</span> •
              <span id="rqbTrainsCount">3 trains</span>
            </div>
          </div>
          <div class="rqb-btn-grid">
            <button type="button" class="rqb-action-btn" id="rqbBtnFillOnly">
              ${getI18n("widgetFillOnly")}
            </button>
            <button type="button" class="rqb-action-btn rqb-btn-primary" id="rqbBtnFillSearch">
              ${getI18n("widgetFillSearch")}
            </button>
            <button type="button" class="rqb-action-btn" id="rqbBtnHighlight">
              ${getI18n("widgetHighlight")}
            </button>
            <button type="button" class="rqb-action-btn" id="rqbBtnFillPax">
              ${getI18n("widgetFillPax")}
            </button>
          </div>
          <div class="rqb-status-bar" id="rqbStatusBar">
            ${getI18n("widgetReady")}
          </div>
        </div>
      `;
      document.body.appendChild(widget);

      // Events
      document.getElementById("rqbWidgetHeader").addEventListener("click", () => {
        widget.classList.toggle("rqb-minimized");
      });

      const toggleInput = document.getElementById("rqbWidgetToggle");
      if (toggleInput) {
        toggleInput.addEventListener("change", () => {
          config.enabled = toggleInput.checked;
          if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ quickbookConfig: config });
          }
          if (config.enabled) {
            highlightPreferredTrains();
            updateWidgetStatus(getI18n("widgetActive"));
          } else {
            highlightPreferredTrains();
            updateWidgetStatus(getI18n("widgetPaused"));
          }
        });
      }

      document.getElementById("rqbBtnFillOnly").addEventListener("click", () => {
        autofillSearchForm(false);
      });

      document.getElementById("rqbBtnFillSearch").addEventListener("click", () => {
        autofillSearchForm(true);
      });

      document.getElementById("rqbBtnHighlight").addEventListener("click", () => {
        hasScrolledCurrentSearch = false;
        const count = highlightPreferredTrains();
        if (count === 0) {
          updateWidgetStatus(config.lang === "bn" ? "ℹ️ এই পেজে এখনো পছন্দের ট্রেন পাওয়া যায়নি।" : "ℹ️ No preferred trains found on this page yet.");
        }
      });

      document.getElementById("rqbBtnFillPax").addEventListener("click", () => {
        const count = autofillPassengerDetails();
        if (count > 0) {
          updateWidgetStatus(getI18n("widgetPaxFilled", { count }));
        } else {
          updateWidgetStatus(config.lang === "bn" ? "ℹ️ যাত্রী তথ্যের ফর্ম পাওয়া যায়নি বা নাম সেভ নেই।" : "ℹ️ Co-passenger form not found or no names saved.");
        }
      });

      startWidgetClock();
    } else {
      widget.style.display = "block";
    }

    // Refresh summary & button text with current language
    const rText = document.getElementById("rqbRouteText");
    const dText = document.getElementById("rqbDateText");
    const cText = document.getElementById("rqbClassText");
    const tCount = document.getElementById("rqbTrainsCount");
    const wToggle = document.getElementById("rqbWidgetToggle");

    const btnFillOnly = document.getElementById("rqbBtnFillOnly");
    const btnFillSearch = document.getElementById("rqbBtnFillSearch");
    const btnHighlight = document.getElementById("rqbBtnHighlight");
    const btnFillPax = document.getElementById("rqbBtnFillPax");

    if (btnFillOnly) btnFillOnly.innerHTML = getI18n("widgetFillOnly");
    if (btnFillSearch) btnFillSearch.innerHTML = getI18n("widgetFillSearch");
    if (btnHighlight) btnHighlight.innerHTML = getI18n("widgetHighlight");
    if (btnFillPax) btnFillPax.innerHTML = getI18n("widgetFillPax");

    if (wToggle) wToggle.checked = config.enabled !== false;
    if (rText) rText.textContent = `${config.fromStation} ➔ ${config.toStation}`;
    if (dText) dText.textContent = formatToRailwayDate(config.journeyDate);
    if (cText) cText.textContent = config.seatClass;
    if (tCount) {
      const trainUnit = isBn ? "টি ট্রেন" : "trains";
      tCount.textContent = `⭐ ${(config.preferredTrains || []).length} ${trainUnit}`;
    }
  }

  function updateWidgetStatus(msg) {
    const statusEl = document.getElementById("rqbStatusBar");
    if (statusEl) statusEl.textContent = msg;
  }

  function startWidgetClock() {
    const updateClock = () => {
      const clockEl = document.getElementById("rqbLiveClock");
      if (!clockEl) return;
      const now = new Date();
      const utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
      const bst = new Date(utcMs + 6 * 3600000);
      const h = bst.getHours();
      const m = String(bst.getMinutes()).padStart(2, "0");
      const s = String(bst.getSeconds()).padStart(2, "0");
      const ampm = h >= 12 ? "PM" : "AM";
      const h12 = String(h % 12 || 12).padStart(2, "0");
      clockEl.textContent = `${h12}:${m}:${s} ${ampm}`;
    };
    updateClock();
    setInterval(updateClock, 1000);
  }

  // =========================================================================
  // 6. Storage Sync, Message Listeners & DOM Observer
  // =========================================================================

  function initStorageAndListeners() {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(["quickbookConfig", "pendingAutoFillOnLoad"], (res) => {
        if (res.quickbookConfig) {
          config = { ...config, ...res.quickbookConfig };
        }
        createOrUpdateFloatingWidget();
        highlightPreferredTrains();

        if (res.pendingAutoFillOnLoad) {
          chrome.storage.local.remove("pendingAutoFillOnLoad");
          setTimeout(() => autofillSearchForm(true), 600);
        }
      });

      // Live update when config changes in Popup
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.quickbookConfig && changes.quickbookConfig.newValue) {
          config = { ...config, ...changes.quickbookConfig.newValue };
          createOrUpdateFloatingWidget();
          highlightPreferredTrains();
        }
      });

      // Listen for Popup or Keyboard Shortcut commands
      chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (message.action === "TRIGGER_AUTOFILL") {
          if (message.config) config = { ...config, ...message.config };
          createOrUpdateFloatingWidget();
          autofillSearchForm();
          sendResponse({ status: "ok" });
        } else if (message.action === "CONFIG_UPDATED") {
          if (message.config) config = { ...config, ...message.config };
          createOrUpdateFloatingWidget();
          highlightPreferredTrains();
          sendResponse({ status: "ok" });
        }
        return true;
      });
    } else {
      createOrUpdateFloatingWidget();
    }

    // In-page keyboard shortcut fallback: Alt + Shift + F
    window.addEventListener("keydown", (e) => {
      if (e.altKey && e.shiftKey && (e.key === "F" || e.key === "f")) {
        e.preventDefault();
        autofillSearchForm();
      }
    });

    // Observe Angular SPA DOM changes (train search results loading, route changes)
    let debounceTimer = null;
    const observer = new MutationObserver((mutations) => {
      if (isApplyingHighlight) return;

      const urlChanged = location.href !== lastUrl;
      if (urlChanged) {
        lastUrl = location.href;
        hasScrolledCurrentSearch = false;
      }

      // Check if any train cards were actually added or removed
      let hasTrainCardChanges = false;
      for (const m of mutations) {
        // Skip changes inside floating widget or plugin badges
        const targetEl = m.target.nodeType === 1 ? m.target : m.target.parentElement;
        if (targetEl && targetEl.closest && targetEl.closest("#rqb-floating-widget, .rqb-preferred-badge, .rqb-preferred-seat-class")) {
          continue;
        }

        if (m.addedNodes && m.addedNodes.length > 0) {
          for (const node of m.addedNodes) {
            if (node.nodeType === 1) {
              if (
                node.tagName === "APP-SINGLE-TRIP" ||
                node.classList?.contains("single-trip-wrapper") ||
                node.classList?.contains("trip-card") ||
                node.querySelector?.("app-single-trip, .single-trip-wrapper, .trip-card, [class*='single-trip']")
              ) {
                hasTrainCardChanges = true;
                break;
              }
            }
          }
        }
        if (hasTrainCardChanges) break;
      }

      if (!urlChanged && !hasTrainCardChanges) return;

      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        highlightPreferredTrains();
      }, 250);
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initStorageAndListeners);
  } else {
    initStorageAndListeners();
  }
})();
